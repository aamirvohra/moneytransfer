export class UserAccountInfo {
  balance: number;
  accountType: string;
  accountNumber: number;
}
