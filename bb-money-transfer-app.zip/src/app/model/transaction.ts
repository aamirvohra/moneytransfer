export class Transaction {
  merchant: string;
  merchantLogo: string;
  amount: number;
  categoryCode: string;
  transactionDate: number;
  displayDate: string;
  transactionType: string;
}
