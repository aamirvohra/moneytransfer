export enum SortOrder {
  'asc',
  'desc'
};
